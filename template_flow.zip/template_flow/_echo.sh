echo "
      job       = $1
      
      PROJECT properties
      project_1 = $2
      project_2 = $3
      project_3 = $4
      
      CUSTOM properties
      custom_1  = $5
      custom_2  = $6
      "
